package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import dto.Book;

@Component
public class BookDao {

	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("hibernate1");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();

	public Book saveBook(Book books) {

		entityTransaction.begin();
		entityManager.persist(books);
		entityTransaction.commit();
		return books;
	}

	public List<Book> findAllBook() {

		Query findAllBook = entityManager.createQuery("select u from Book u");
		List<Book> bookList = findAllBook.getResultList();
		return bookList;
	}

	public Book findBookById(int id) {
		entityTransaction.begin();
		Book dbBook = entityManager.find(Book.class, id);
		entityTransaction.commit();
		return dbBook;
	}

	public Book updateBook(Book book)
	{
		entityTransaction.begin();
		entityManager.merge(book);
		entityTransaction.commit();
		return book;
	}

	public Book deleteBook(Book book)
	{
		entityTransaction.begin();
		entityManager.remove(book);
		entityTransaction.commit();
		return book;
	}

}
