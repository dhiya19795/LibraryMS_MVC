package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import dto.Book;
import dto.Users;

@Component
public class UsersDao {

	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("hibernate1");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();


	public Users saveUser(Users users) {

		entityTransaction.begin();
		entityManager.persist(users);
		entityTransaction.commit();
		return users;
	}
	
	public List<Users> findAllUser() {

		Query findAllUser = entityManager.createQuery("select u from Users u");
		List<Users> userList = findAllUser.getResultList();
		return userList;
	}
	
	public Users findUsersById(int id) {
		entityTransaction.begin();
		Users dbUser = entityManager.find(Users.class, id);
		entityTransaction.commit();
		return dbUser;

	}
	
	public Users updateUser(int uId,String uName)
	{
		Users user = entityManager.find(Users.class, uId);
		user.setId(uId);
		user.setName(uName);
		entityTransaction.begin();
		entityManager.merge(user);
		entityTransaction.commit();
		return user;
	}
	
	public void deleteUser(int id)
	{
		
		entityTransaction.begin();
		Users dbUser = entityManager.find(Users.class, id);
		entityManager.remove(dbUser);
		entityTransaction.commit();

	}
	

	
}

	
	
	
	
	
	
	
	
	
	
//	public Users updateUser(Users users)
//	{
//		entityTransaction.begin();
//		entityManager.merge(users);
//		entityTransaction.commit();
//		return users;
//	}
	
	

