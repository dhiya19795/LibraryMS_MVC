package dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Entity
@Component// This class is the spring managed bean class that is this class will instantiated and inject any dependencies automatically into them.
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "book_id")
	@SequenceGenerator(name="book_id",initialValue = 201,allocationSize = 1)
	private int id;
	private String title;
	private String author;
	private boolean borrowed;
	@ManyToOne
	@JoinColumn(name="Users_id")
	private Users borrowedBy;


}
