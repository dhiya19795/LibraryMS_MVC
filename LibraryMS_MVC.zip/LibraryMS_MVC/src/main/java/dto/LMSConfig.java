package dto;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration // This class is having bean definition methods
@ComponentScan(basePackages = {"controller","dto","dao"})
public class LMSConfig {

}
