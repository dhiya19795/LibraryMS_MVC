package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.UsersDao;
import dto.Users;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class LMSController {
	@Autowired
	Users users;
	@Autowired
	UsersDao usersDao;

	@PostMapping("/save")
	public ModelAndView saveUsers(HttpServletRequest req,HttpServletResponse res)
	{
		Users users = new Users();
		String name = req.getParameter("name");
		users.setName(name);
		usersDao.saveUser(users);
		ModelAndView modelAndView = new ModelAndView("frontPage.jsp");
		return modelAndView;

	}

	@GetMapping("/findAllUser")
	public String getListofUsers(Model model)
	{	
		List<Users> userList = usersDao.findAllUser();
		model.addAttribute("user", userList);
		return "fetchUser.jsp";
	}

	@GetMapping("/findById")
	public String findUsersById(HttpServletRequest req,HttpServletResponse res,Model model)
	{
		String id = req.getParameter("id");
		int userId = Integer.parseInt(id);
		Users dbusers = usersDao.findUsersById(userId);
		model.addAttribute("user", dbusers);
		return "fetchUserByIdDisplay.jsp";
	}
	
	@GetMapping("/update")
	public String UpdateUsers(HttpServletRequest req,HttpServletResponse res,Model model)
	{
		String id = req.getParameter("id");
		int userId= Integer.parseInt(id);
		Users users = usersDao.findUsersById(userId);
		
		model.addAttribute("usersId", users);
		return "updateUserDisplay.jsp";
		
	}

	@GetMapping("/edit")
	public String editUsers(HttpServletRequest req,HttpServletResponse res,Model model) 
	{
		int userId = Integer.parseInt(req.getParameter("id"));
		String userName = req.getParameter("name");
		Users users = usersDao.updateUser(userId,userName);
		model.addAttribute("usersId", users);
		return "frontPage.jsp";

	}
	
	@GetMapping("/delete")
	public ModelAndView deleteUsers(HttpServletRequest req,HttpServletResponse res) 
	{
		String id = req.getParameter("id");
		int userId= Integer.parseInt(id);
		usersDao.deleteUser(userId);
		ModelAndView modelAndView = new ModelAndView("frontPage.jsp");
		return modelAndView;
		

	}


}
