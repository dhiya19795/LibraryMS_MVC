package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.BookDao;
import dao.UsersDao;
import dto.Book;
import dto.Users;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class BookController {

	@Autowired
	Book book;
	@Autowired
	BookDao bookDao;
	@Autowired
	UsersDao usersdao;


	@PostMapping("/saveBook")
	public ModelAndView saveBook(HttpServletRequest req,HttpServletResponse res)
	{
		Book book = new Book();
		String title = req.getParameter("title");
		String  author = req.getParameter("author");

		book.setTitle(title);
		book.setAuthor(author);

		bookDao.saveBook(book);

		ModelAndView modelAndView = new ModelAndView("frontPage.jsp");
		return modelAndView;
	}


	@GetMapping("/findAllBook")
	public String getListofBook(Model model)
	{	
		List<Book> bookList = bookDao.findAllBook();
		model.addAttribute("book", bookList);
		return "fetchBook.jsp";
	}

	@GetMapping("/findBookById")
	public String findBookById(HttpServletRequest req,HttpServletResponse res,Model model)
	{
		String id = req.getParameter("id");
		int bookId = Integer.parseInt(id);
		Book dbBook = bookDao.findBookById(bookId);
		model.addAttribute("book", dbBook);
		return "fetchBookByIdDisplay.jsp";
	}

	/** @GetMapping("/findBoodById")
	public ModelAndView getBookById(HttpServletRequest req,HttpServletResponse res)
	{
		String id = req.getParameter("id");
		int bookId = Integer.parseInt(id);
		Book dbBook = bookDao.findBookById(bookId);
		ModelAndView modelAndView = new ModelAndView("fetchBookByIdDisplay.jsp");
		modelAndView.addObject("book", dbBook);
		return modelAndView;
	} **/

	@GetMapping("/updateBook")
	public String UpdateUsers(HttpServletRequest req,HttpServletResponse res,Model model)
	{
		String id = req.getParameter("id");
		int bookId= Integer.parseInt(id);



		Book dbBook = bookDao.findBookById(bookId);

		dbBook.setId(bookId);
		dbBook.getTitle();
		dbBook.getAuthor();
		model.addAttribute("book", dbBook);
		return "updateBookDisplay.jsp";
	}

	@GetMapping("/editBook")
	public String editUsers(HttpServletRequest req,HttpServletResponse res,Model model)
	{
		int bookId =  Integer.parseInt(req.getParameter("id"));
		String title = req.getParameter("title");
		String author = req.getParameter("author");

		Book book = bookDao.findBookById(bookId);
		book.setId(bookId);
		book.setTitle(title);
		book.setAuthor(author);
		Book dbBook = bookDao.updateBook(book);

		model.addAttribute("book", dbBook);
		return "frontPage.jsp";
	}

	@GetMapping("/deleteBook")
	public ModelAndView deleteBook(HttpServletRequest req,HttpServletResponse res) 
	{
		String id = req.getParameter("id");
		int bookId= Integer.parseInt(id);
		Book book = bookDao.findBookById(bookId);
		bookDao.deleteBook(book);
		ModelAndView modelAndView = new ModelAndView("frontPage.jsp");
		return modelAndView;
	}

	@GetMapping("/borrowBook")
	public ModelAndView borrowBpook(HttpServletRequest req,HttpServletResponse res)
	{
		String bid = req.getParameter("bid");
		int bookId= Integer.parseInt(bid);
		String uid = req.getParameter("uid");
		int userId= Integer.parseInt(uid);

		Book book = bookDao.findBookById(bookId);
		Users user = usersdao.findUsersById(userId);

		if (book !=null && user!=null && !book.isBorrowed())
		{
			book.setBorrowedBy(user);
			book.setBorrowed(true);

			bookDao.updateBook(book);
		}
		else {
			ModelAndView modelAndView = new ModelAndView("alert.jsp");
			return modelAndView;
		}
		ModelAndView modelAndView = new ModelAndView("frontPage.jsp");
		return modelAndView;

	}

	@PostMapping("/returnBook")
	public ModelAndView returnBook(HttpServletRequest req,HttpServletResponse res)
	{
		String bid = req.getParameter("bid");
		int bookId= Integer.parseInt(bid);

		Book book = bookDao.findBookById(bookId);
		if(book !=null && book.isBorrowed() )
		{
			book.setBorrowedBy(null);
			book.setBorrowed(false);

			bookDao.updateBook(book);

		}
		else {
			ModelAndView modelAndView = new ModelAndView("alert.jsp");
			return modelAndView;
		}

		ModelAndView modelAndView = new ModelAndView("frontPage.jsp");
		return modelAndView;
	}
}

//@PostMapping("/update")
//public ModelAndView updateBook(HttpServletRequest req,HttpServletResponse res)
//{
//	String title = req.getParameter("title");
//	String author = req.getParameter("author");
//	int id = Integer.parseInt(req.getParameter("id"));
//	
//	Book book = bookDao.findBookById(id);
//	
//	if (title!=null) {
//		book.setTitle(title);
//	}
//	else if (author!=null) {
//		book.setAuthor(author);
//	}
//	
//	
//	ModelAndView modelAndView = new ModelAndView("frontPage.jsp");
//	return modelAndView;
//}
//
